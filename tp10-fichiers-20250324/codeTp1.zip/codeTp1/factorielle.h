
int factorielle(int a);

